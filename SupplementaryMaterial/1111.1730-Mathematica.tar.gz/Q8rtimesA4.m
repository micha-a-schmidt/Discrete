Group = ModelBuilding`DiscreteSymmetries`Private`Group$705
 
Attributes[ModelBuilding`DiscreteSymmetries`Private`Group$705] = {Temporary}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 1] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 2] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 3] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 4] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 5] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 6] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 7] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 8] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 9] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 10] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][1, 11] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 1] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 2] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 3] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 4] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 5] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 6] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 7] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 8] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 9] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 10] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][2, 11] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 1] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 2] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 3] = {{1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 4] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 5] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 6] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 7] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 8] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 9] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 10] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][3, 11] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 1] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 2] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 3] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 4] = 
    {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {1/Sqrt[3], ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {1/Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 5] = 
    {{1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 6] = 
    {{1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 7] = 
    {{0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {1, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 8] = 
    {{0, 0, 1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 9] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3]}, {1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 
      0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3]}, {0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 
      0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 10] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3])}, {(-1)^(2/3)/Sqrt[3], 0, 0, 
      0, 1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, 
     {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, 
     {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][4, 11] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 
      0, 0, 1/Sqrt[3], 0}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0}, {(-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 
      0, 0, 0, 1/Sqrt[3], 0, 0, 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3]}, {0, 0, (-1)^(2/3)/Sqrt[3], 
      0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 1] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 2] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 3] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 4] = 
    {{1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 5] = 
    {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {1/Sqrt[3], ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {1/Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 6] = 
    {{1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 7] = 
    {{0, 0, 0, 0, 0, 0, 1, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 1, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 8] = 
    {{0, 0, 0, 0, 0, 0, 1, 0, 0}, {0, 1, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 9] = 
    {{1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, {-(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3]}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 10] = 
    {{1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0}, 
     {0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3])}, {(-1)^(1/3)/Sqrt[3], 0, 0, 
      0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, 
     {0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 
      0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, 
     {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3]}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][5, 11] = 
    {{1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3]}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 1] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 2] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 3] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 4] = 
    {{1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 5] = 
    {{1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 6] = 
    {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {1/Sqrt[3], ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {1/Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 7] = 
    {{0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 8] = 
    {{0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 9] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3]}, {-(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/
       (2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3]}, {0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 
      0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 10] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3])}, {-((-1)^(2/3)/Sqrt[3]), 0, 
      0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 
      0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, 
     {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][6, 11] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0, 0}, {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0}, 
     {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3]}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 
      0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 1] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 2] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 3] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 4] = 
    {{0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {1, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 5] = 
    {{0, 0, 0, 0, 0, 0, 1, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 1, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 6] = 
    {{0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 7] = 
    {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {1/Sqrt[3], ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {1/Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 8] = 
    {{0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 9] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3])}, 
     {1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3])}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 10] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3])}, 
     {(-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 
      0, 0, 0}, {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 
      0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3])}, 
     {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][7, 11] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0}, {0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0}, {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0}, 
     {0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 
      0, 0, 0, -(1/Sqrt[3])}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 1] = 
    {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 2] = 
    {{1, 0, 0}, {0, (-1)^(2/3), 0}, {0, 0, -(-1)^(1/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 3] = 
    {{1, 0, 0}, {0, -(-1)^(1/3), 0}, {0, 0, (-1)^(2/3)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 4] = 
    {{0, 0, 1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 5] = 
    {{0, 0, 0, 0, 0, 0, 1, 0, 0}, {0, 0, 0, 1, 0, 0, 0, 0, 0}, 
     {1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 6] = 
    {{0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 7] = 
    {{0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, 
     {0, 0, 0, 0, 1, 0, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 8] = 
    {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 1, 0}, 
     {0, 0, 0, 0, 0, 0, 0, 0, 1}, {1/Sqrt[3], ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 1, 0, 0}, {1/Sqrt[3], ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 9] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3])}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/
       (2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 
      0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/
       (2*Sqrt[3])}, {0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 10] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0}, {0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3])}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0}, 
     {0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, 
     {0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3])}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][8, 11] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 
      0, 0, 1/Sqrt[3], 0}, {0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0, 0}, {(-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 
      0, 0, 0, -(1/Sqrt[3])}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 1] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 2] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 3] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 4] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0}, {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 
      0}, {0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3]}, {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 
      0}, {0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, {1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3]}, {1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 5] = 
    {{1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {-(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 
      0, 0}, {0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 
      0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3]}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3]}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 6] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3])}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0}, {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 
      0}, {0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3])}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, {1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 
      0, 0, -(1/Sqrt[3])}, {-(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 7] = 
    {{0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0}, {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3]}, {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 
      0, 1/Sqrt[3], 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0}, {-(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 
      0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 
      0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 8] = 
    {{0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3])}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0}, {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0}, 
     {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3])}, {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, 
     {-(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, {1/Sqrt[3], 0, 0, 0, 
      ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0}, {0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/
       Sqrt[3], 0, 0, 0, ((-I/2)*(-I + Sqrt[3]))/Sqrt[3], 0, 0}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 9] = 
    {{1/2, 0, 0, 0, 1/2, -1/2, -1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2}, 
     {1/2, 0, 0, 0, -1/2, 1/2, -1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2, 0, 0}, 
     {1/2, 0, 0, 0, -1/2, -1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2}, 
     {1/2, 0, 0, 0, 1/2, 1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 10] = 
    {{1/2, 0, 0, 0, 1/2, -(-1)^(2/3)/2, (-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, 
      (-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2}, {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2}, {1/2, 0, 0, 0, -1/2, (-1)^(2/3)/2, 
      (-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 
      0, 0, -1/2, 0, 0, 1/2, 0, 0}, {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, 
      (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0}, 
     {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 
      0, 0, (-1)^(2/3)/2, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, 
      -1/2, 0, 0}, {1/2, 0, 0, 0, -1/2, -(-1)^(2/3)/2, -(-1)^(1/3)/2, 0, 0, 
      0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0, 0}, 
     {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 
      0, 0, -(-1)^(2/3)/2, 0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2}, 
     {1/2, 0, 0, 0, 1/2, (-1)^(2/3)/2, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][9, 11] = 
    {{1/2, 0, 0, 0, 1/2, (-1)^(1/3)/2, -(-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}, {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 
      0, (-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, 
      (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2}, {1/2, 0, 0, 0, -1/2, -(-1)^(1/3)/2, 
      -(-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1/2, 0, 0, 0, 0, 0, 
      -1/2, 0, 0, -1/2, 0, 0, 1/2, 0, 0}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 
      0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0}, 
     {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 
      0, 0, -(-1)^(1/3)/2, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, 
      -1/2, 0, 0}, {1/2, 0, 0, 0, -1/2, (-1)^(1/3)/2, (-1)^(2/3)/2, 0, 0, 0, 
      0, 0, 0, 0, 0, 0}, {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 
      0, 0, (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2}, {0, 1/2, 0, 0, 0, 0, 0, 1/2, 
      0, 0, -1/2, 0, 0, -1/2, 0, 0}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0}, 
     {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2}, {1/2, 0, 0, 0, 1/2, -(-1)^(1/3)/2, 
      (-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 1] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 2] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 3] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 4] = 
    {{0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3])}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {(-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 
      0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 5] = 
    {{1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {(-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3])}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3]}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 6] = 
    {{0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3])}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0}, {0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3])}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0}, 
     {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 7] = 
    {{0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3])}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 
      0, 1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3]}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {(-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, {0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 8] = 
    {{0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3])}, {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0}, {0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3])}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0}, {(-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0}, 
     {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {(-1)^(2/3)/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 
      0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 
      ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0}, {0, 0, 1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 9] = 
    {{1/2, 0, 0, 0, 1/2, -(-1)^(2/3)/2, (-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, 
      (-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2}, {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2}, {1/2, 0, 0, 0, -1/2, (-1)^(2/3)/2, 
      (-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 
      0, 0, -1/2, 0, 0, 1/2, 0, 0}, {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, 
      (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0}, 
     {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 
      0, 0, (-1)^(2/3)/2, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, 
      -1/2, 0, 0}, {1/2, 0, 0, 0, -1/2, -(-1)^(2/3)/2, -(-1)^(1/3)/2, 0, 0, 
      0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0, 0}, 
     {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 
      0, 0, -(-1)^(2/3)/2, 0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2}, 
     {1/2, 0, 0, 0, 1/2, (-1)^(2/3)/2, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 10] = 
    {{1/2, 0, 0, 0, 1/2, (-1)^(1/3)/2, -(-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}, {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 
      0, (-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, 
      (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2}, {1/2, 0, 0, 0, -1/2, -(-1)^(1/3)/2, 
      -(-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1/2, 0, 0, 0, 0, 0, 
      -1/2, 0, 0, -1/2, 0, 0, 1/2, 0, 0}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 
      0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0}, 
     {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 
      0, 0, -(-1)^(1/3)/2, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, 
      -1/2, 0, 0}, {1/2, 0, 0, 0, -1/2, (-1)^(1/3)/2, (-1)^(2/3)/2, 0, 0, 0, 
      0, 0, 0, 0, 0, 0}, {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 
      0, 0, (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2}, {0, 1/2, 0, 0, 0, 0, 0, 1/2, 
      0, 0, -1/2, 0, 0, -1/2, 0, 0}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0}, 
     {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2}, {1/2, 0, 0, 0, 1/2, -(-1)^(1/3)/2, 
      (-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][10, 11] = 
    {{1/2, 0, 0, 0, 1/2, -1/2, -1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2}, 
     {1/2, 0, 0, 0, -1/2, 1/2, -1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2, 0, 0}, 
     {1/2, 0, 0, 0, -1/2, -1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2}, 
     {1/2, 0, 0, 0, 1/2, 1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 1] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 2] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 3] = 
    {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 4] = 
    {{0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      0, 0, 0, 1/Sqrt[3]}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 
      0, 0, 1/Sqrt[3], 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3]}, {1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 
      0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {(-1)^(2/3)/Sqrt[3], 0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 
      0, 0, 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0}, {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 5] = 
    {{1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, 1/Sqrt[3], 0, 0}, {0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}, 
     {0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3]}, 
     {0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      0, 0, 0, 1/Sqrt[3]}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3]}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 6] = 
    {{0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0, 0, -(1/Sqrt[3])}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 
      0, 0, 1/Sqrt[3], 0}, {0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, 1/Sqrt[3], 0, 0}, {(-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {(-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 7] = 
    {{0, 0, 0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 
      0, 0, 0, 1/Sqrt[3]}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0}, {0, 0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3]}, {1/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, {0, -((-1)^(1/3)/Sqrt[3]), 0, 
      0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, 
      -(1/Sqrt[3]), 0, 0, 0}, {0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 
      0, 1/Sqrt[3]}, {(-1)^(1/3)/Sqrt[3], 0, 0, 0, 
      (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0}, 
     {0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0, 0}, {0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 
      0, 0, -(1/Sqrt[3]), 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 8] = 
    {{0, 0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 
      0, 0, -(1/Sqrt[3])}, {0, 0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0}, 
     {0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0}, 
     {0, 0, (-1)^(1/3)/Sqrt[3], 0, 0, 0, (1 - I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 
      0, -(1/Sqrt[3]), 0}, {0, 0, 0, -((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0}, 
     {0, -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 
      0, 1/Sqrt[3], 0, 0}, {-((-1)^(2/3)/Sqrt[3]), 0, 0, 0, 
      (1 + I*Sqrt[3])/(2*Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0}, 
     {0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3]), 0, 0, 0, -(1/Sqrt[3])}, 
     {-((-1)^(1/3)/Sqrt[3]), 0, 0, 0, ((I/2)*(I + Sqrt[3]))/Sqrt[3], 0, 0, 0, 
      1/Sqrt[3], 0, 0, 0}, {0, (-1)^(2/3)/Sqrt[3], 0, 0, 0, 
      -((-1)^(1/3)/Sqrt[3]), 0, 0, 0, 1/Sqrt[3], 0, 0}, 
     {0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0, 0, 0, 1/Sqrt[3], 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 9] = 
    {{1/2, 0, 0, 0, 1/2, (-1)^(1/3)/2, -(-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}, {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 
      0, (-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, 
      (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2}, {1/2, 0, 0, 0, -1/2, -(-1)^(1/3)/2, 
      -(-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1/2, 0, 0, 0, 0, 0, 
      -1/2, 0, 0, -1/2, 0, 0, 1/2, 0, 0}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 
      0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0}, 
     {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 
      0, 0, -(-1)^(1/3)/2, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, 
      -1/2, 0, 0}, {1/2, 0, 0, 0, -1/2, (-1)^(1/3)/2, (-1)^(2/3)/2, 0, 0, 0, 
      0, 0, 0, 0, 0, 0}, {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 
      0, 0, (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2}, {0, 1/2, 0, 0, 0, 0, 0, 1/2, 
      0, 0, -1/2, 0, 0, -1/2, 0, 0}, {0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0}, 
     {0, 0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2}, {1/2, 0, 0, 0, 1/2, -(-1)^(1/3)/2, 
      (-1)^(2/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 10] = 
    {{1/2, 0, 0, 0, 1/2, -1/2, -1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2}, 
     {1/2, 0, 0, 0, -1/2, 1/2, -1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, -1/2, 0, 0, 1/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, -1/2, 0, 0}, 
     {1/2, 0, 0, 0, -1/2, -1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0, 0}, 
     {0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0}, 
     {0, 0, 0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2}, 
     {1/2, 0, 0, 0, 1/2, 1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CGcoeff"][11, 11] = 
    {{1/2, 0, 0, 0, 1/2, -(-1)^(2/3)/2, (-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, 
      (-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2}, {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 0}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 1/2, 0, 0, 1/2, 0, 0}, 
     {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, (-1)^(1/3)/2, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2}, {1/2, 0, 0, 0, -1/2, (-1)^(2/3)/2, 
      (-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 
      0, 0, -1/2, 0, 0, 1/2, 0, 0}, {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, 
      (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0, 0, (-1)^(2/3)/2, 0}, 
     {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, -(-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 
      0, 0, (-1)^(2/3)/2, 0}, {0, 1/2, 0, 0, 0, 0, 0, -1/2, 0, 0, 1/2, 0, 0, 
      -1/2, 0, 0}, {1/2, 0, 0, 0, -1/2, -(-1)^(2/3)/2, -(-1)^(1/3)/2, 0, 0, 
      0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2, 0, 0, -(-1)^(1/3)/2}, 
     {0, 1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, -1/2, 0, 0, -1/2, 0, 0}, 
     {0, 0, (-1)^(2/3)/2, 0, 0, 0, 0, 0, (-1)^(2/3)/2, 0, 0, -(-1)^(2/3)/2, 
      0, 0, -(-1)^(2/3)/2, 0}, {0, 0, 0, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 
      -(-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2, 0, 0, (-1)^(1/3)/2}, 
     {1/2, 0, 0, 0, 1/2, (-1)^(2/3)/2, -(-1)^(1/3)/2, 0, 0, 0, 0, 0, 0, 0, 0, 
      0}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     1] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     2] = {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     3] = {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     4] = {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     5] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     6] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     7] = {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     8] = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][1, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     1] = {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     2] = {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     3] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     4] = {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     5] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     6] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     7] = {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     8] = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][2, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     1] = {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     2] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     3] = {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     4] = {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     5] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     6] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     7] = {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     8] = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][3, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     1] = {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     2] = {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     3] = {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     4] = {1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     5] = {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     6] = {0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     7] = {0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     8] = {0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][4, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     1] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     2] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     3] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     4] = {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     5] = {1, 1, 1, 0, 2, 0, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     6] = {0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     7] = {0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     8] = {0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][5, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     1] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     2] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     3] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     4] = {0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     5] = {0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     6] = {1, 1, 1, 0, 0, 2, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     7] = {0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     8] = {0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][6, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     1] = {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     2] = {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     3] = {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     4] = {0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     5] = {0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     6] = {0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     7] = {1, 1, 1, 0, 0, 0, 2, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     8] = {0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][7, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     1] = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     2] = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     3] = {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     4] = {0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     5] = {0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     6] = {0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     7] = {0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     8] = {1, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     9] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][8, 
     11] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     1] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     2] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     3] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     4] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     5] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     6] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     7] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     8] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     9] = {1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     10] = {0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][9, 
     11] = {0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     1] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     2] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     3] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     4] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     5] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     6] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     7] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     8] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     9] = {0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     10] = {0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][10, 
     11] = {1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     1] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     2] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     3] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     4] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     5] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     6] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     7] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     8] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     9] = {0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     10] = {1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["KroneckerProduct"][11, 
     11] = {0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["CharacterTable"] = 
    {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, {1, E^(((-2*I)/3)*Pi), 1, 1, 1, 
      E^(((2*I)/3)*Pi), E^(((-2*I)/3)*Pi), 1, 1, 1, E^(((2*I)/3)*Pi)}, 
     {1, E^(((2*I)/3)*Pi), 1, 1, 1, E^(((-2*I)/3)*Pi), E^(((2*I)/3)*Pi), 1, 
      1, 1, E^(((-2*I)/3)*Pi)}, {3, 0, 3, -1, 3, 0, 0, -1, -1, -1, 0}, 
     {3, 0, -1, 3, 3, 0, 0, -1, -1, -1, 0}, {3, 0, -1, -1, 3, 0, 0, 3, -1, 
      -1, 0}, {3, 0, -1, -1, 3, 0, 0, -1, -1, 3, 0}, 
     {3, 0, -1, -1, 3, 0, 0, -1, 3, -1, 0}, {4, 1, 0, 0, -4, 1, -1, 0, 0, 0, 
      -1}, {4, E^(((-2*I)/3)*Pi), 0, 0, -4, E^(((2*I)/3)*Pi), 
      -E^(((-2*I)/3)*Pi), 0, 0, 0, -E^(((2*I)/3)*Pi)}, 
     {4, E^(((2*I)/3)*Pi), 0, 0, -4, E^(((-2*I)/3)*Pi), -E^(((2*I)/3)*Pi), 0, 
      0, 0, -E^(((-2*I)/3)*Pi)}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["DimensionsOfReps"] = 
    {1, 1, 1, 3, 3, 3, 3, 3, 4, 4, 4}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["Name"] = 
    "SmallGroup(96,204)"
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["NumberOfReps"] = 11
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["NumericalEvaluate"] = 
    False
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["RepMatrices"] = 
    {{{{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}}, {{{1}}, {{-(-1)^(1/3)}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{(-1)^(2/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{1}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{-(-1)^(1/3)}}, {{(-1)^(2/3)}}}, 
     {{{1}}, {{(-1)^(2/3)}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{-(-1)^(1/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, 
      {{1}}, {{1}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{1}}, {{1}}, {{1}}, {{1}}, {{1}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, 
      {{(-1)^(2/3)}}, {{(-1)^(2/3)}}, {{1}}, {{-(-1)^(1/3)}}, 
      {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, {{-(-1)^(1/3)}}, 
      {{(-1)^(2/3)}}, {{-(-1)^(1/3)}}}, {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}}, {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}}, 
     {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}}, {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}}, {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, 
       {0, 0, 1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, 
       {0, 0, -1}}, {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, 
      {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, -1, 0}, 
       {0, 0, -1}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, 
      {{0, 1, 0}, {0, 0, -1}, {-1, 0, 0}}, {{0, -1, 0}, {0, 0, -1}, 
       {1, 0, 0}}, {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, 
      {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, {{1, 0, 0}, {0, -1, 0}, {0, 0, -1}}, 
      {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}}, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, 1}, {-1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{0, -1, 0}, {0, 0, -1}, {1, 0, 0}}, {{0, 1, 0}, {0, 0, -1}, 
       {-1, 0, 0}}, {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}}, 
      {{-1, 0, 0}, {0, -1, 0}, {0, 0, 1}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}}, {{0, 0, -1}, {-1, 0, 0}, 
       {0, 1, 0}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, 
      {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}}, {{0, 0, 1}, {-1, 0, 0}, 
       {0, -1, 0}}}, {{{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, 1}}, {{0, 1, 0, 0}, {0, 0, 1, 0}, {1, 0, 0, 0}, 
       {0, 0, 0, 1}}, {{0, 0, 1, 0}, {0, 0, 0, 1}, {1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, 1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 1}, 
       {0, 0, 1, 0}}, {{-1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, -1, 0}, 
       {0, 0, 0, 1}}, {{-1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, 1}}, {{-1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, -1, 0}, 
       {0, 0, 0, -1}}, {{0, 0, 1, 0}, {1, 0, 0, 0}, {0, 1, 0, 0}, 
       {0, 0, 0, 1}}, {{0, 0, 0, 1}, {1, 0, 0, 0}, {0, 0, 1, 0}, 
       {0, 1, 0, 0}}, {{1, 0, 0, 0}, {0, 0, 0, 1}, {0, 1, 0, 0}, 
       {0, 0, 1, 0}}, {{0, 1, 0, 0}, {0, 0, -1, 0}, {-1, 0, 0, 0}, 
       {0, 0, 0, 1}}, {{0, -1, 0, 0}, {0, 0, 1, 0}, {-1, 0, 0, 0}, 
       {0, 0, 0, 1}}, {{0, -1, 0, 0}, {0, 0, -1, 0}, {-1, 0, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, 0, 1}, {0, 0, 1, 0}, {0, 1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, -1, 0}, {0, 0, 0, 1}, {-1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, 0, 1, 0}, {0, 0, 0, 1}, {-1, 0, 0, 0}, 
       {0, -1, 0, 0}}, {{0, 0, -1, 0}, {0, 0, 0, -1}, {-1, 0, 0, 0}, 
       {0, -1, 0, 0}}, {{0, 1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, 1}, 
       {0, 0, -1, 0}}, {{0, -1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, 1}, 
       {0, 0, 1, 0}}, {{0, -1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, -1, 0}}, {{1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, -1, 0}, 
       {0, 0, 0, 1}}, {{1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, -1}}, {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, -1, 0}, 
       {0, 0, 0, -1}}, {{1, 0, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}, 
       {0, 1, 0, 0}}, {{0, 0, 0, 1}, {0, 1, 0, 0}, {1, 0, 0, 0}, 
       {0, 0, 1, 0}}, {{0, 0, -1, 0}, {-1, 0, 0, 0}, {0, 1, 0, 0}, 
       {0, 0, 0, 1}}, {{0, 0, 1, 0}, {-1, 0, 0, 0}, {0, -1, 0, 0}, 
       {0, 0, 0, 1}}, {{0, 0, -1, 0}, {-1, 0, 0, 0}, {0, -1, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, 1, 0}, {0, 1, 0, 0}, {0, 0, 0, 1}, 
       {1, 0, 0, 0}}, {{0, 0, 0, 1}, {-1, 0, 0, 0}, {0, 0, -1, 0}, 
       {0, 1, 0, 0}}, {{0, 0, 0, 1}, {-1, 0, 0, 0}, {0, 0, 1, 0}, 
       {0, -1, 0, 0}}, {{0, 0, 0, -1}, {-1, 0, 0, 0}, {0, 0, -1, 0}, 
       {0, -1, 0, 0}}, {{-1, 0, 0, 0}, {0, 0, 0, 1}, {0, 1, 0, 0}, 
       {0, 0, -1, 0}}, {{-1, 0, 0, 0}, {0, 0, 0, 1}, {0, -1, 0, 0}, 
       {0, 0, 1, 0}}, {{-1, 0, 0, 0}, {0, 0, 0, -1}, {0, -1, 0, 0}, 
       {0, 0, -1, 0}}, {{0, -1, 0, 0}, {0, 0, -1, 0}, {1, 0, 0, 0}, 
       {0, 0, 0, 1}}, {{0, -1, 0, 0}, {0, 0, 1, 0}, {1, 0, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 1, 0, 0}, {0, 0, -1, 0}, {1, 0, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, 0, 1}, {0, 0, -1, 0}, {0, 1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, 0, 0, 1}, {0, 0, 1, 0}, {0, -1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, -1, 0}, {0, -1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, 0, -1, 0}, {0, 0, 0, 1}, {1, 0, 0, 0}, 
       {0, -1, 0, 0}}, {{0, 0, 1, 0}, {0, 0, 0, -1}, {1, 0, 0, 0}, 
       {0, -1, 0, 0}}, {{0, 0, -1, 0}, {0, 0, 0, -1}, {1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, -1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 1}, 
       {0, 0, -1, 0}}, {{0, -1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, 1, 0}}, {{0, 1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, -1, 0}}, {{-1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, -1}}, {{0, 1, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}, 
       {1, 0, 0, 0}}, {{-1, 0, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 1}, 
       {0, 1, 0, 0}}, {{-1, 0, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}, 
       {0, -1, 0, 0}}, {{-1, 0, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, -1}, 
       {0, -1, 0, 0}}, {{0, 0, 0, 1}, {0, 1, 0, 0}, {-1, 0, 0, 0}, 
       {0, 0, -1, 0}}, {{0, 0, 0, 1}, {0, -1, 0, 0}, {-1, 0, 0, 0}, 
       {0, 0, 1, 0}}, {{0, 0, 0, -1}, {0, -1, 0, 0}, {-1, 0, 0, 0}, 
       {0, 0, -1, 0}}, {{0, 0, -1, 0}, {1, 0, 0, 0}, {0, -1, 0, 0}, 
       {0, 0, 0, 1}}, {{0, 0, 1, 0}, {1, 0, 0, 0}, {0, -1, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, -1, 0}, {1, 0, 0, 0}, {0, 1, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, -1, 0}, {0, 1, 0, 0}, {0, 0, 0, 1}, 
       {-1, 0, 0, 0}}, {{0, 0, 1, 0}, {0, -1, 0, 0}, {0, 0, 0, 1}, 
       {-1, 0, 0, 0}}, {{0, 0, -1, 0}, {0, -1, 0, 0}, {0, 0, 0, -1}, 
       {-1, 0, 0, 0}}, {{0, 0, 0, 1}, {1, 0, 0, 0}, {0, 0, -1, 0}, 
       {0, -1, 0, 0}}, {{0, 0, 0, -1}, {1, 0, 0, 0}, {0, 0, 1, 0}, 
       {0, -1, 0, 0}}, {{0, 0, 0, -1}, {1, 0, 0, 0}, {0, 0, -1, 0}, 
       {0, 1, 0, 0}}, {{1, 0, 0, 0}, {0, 0, 0, 1}, {0, -1, 0, 0}, 
       {0, 0, -1, 0}}, {{1, 0, 0, 0}, {0, 0, 0, -1}, {0, -1, 0, 0}, 
       {0, 0, 1, 0}}, {{1, 0, 0, 0}, {0, 0, 0, -1}, {0, 1, 0, 0}, 
       {0, 0, -1, 0}}, {{0, 1, 0, 0}, {0, 0, 1, 0}, {-1, 0, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, 0, 1}, {0, 0, -1, 0}, {0, -1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, 1, 0}, {0, -1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, -1, 0}, {0, 1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 1, 0}, {0, 0, 0, -1}, {-1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, 1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, 1, 0}}, {{0, 1, 0, 0}, {0, 0, 0, 1}, {0, 0, -1, 0}, 
       {-1, 0, 0, 0}}, {{0, -1, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}, 
       {-1, 0, 0, 0}}, {{0, -1, 0, 0}, {0, 0, 0, -1}, {0, 0, -1, 0}, 
       {-1, 0, 0, 0}}, {{1, 0, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 1}, 
       {0, -1, 0, 0}}, {{1, 0, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, -1}, 
       {0, -1, 0, 0}}, {{1, 0, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, -1}, 
       {0, 1, 0, 0}}, {{0, 0, 0, 1}, {0, -1, 0, 0}, {1, 0, 0, 0}, 
       {0, 0, -1, 0}}, {{0, 0, 0, -1}, {0, -1, 0, 0}, {1, 0, 0, 0}, 
       {0, 0, 1, 0}}, {{0, 0, 0, -1}, {0, 1, 0, 0}, {1, 0, 0, 0}, 
       {0, 0, -1, 0}}, {{0, 0, 1, 0}, {-1, 0, 0, 0}, {0, 1, 0, 0}, 
       {0, 0, 0, -1}}, {{0, 0, -1, 0}, {0, -1, 0, 0}, {0, 0, 0, 1}, 
       {1, 0, 0, 0}}, {{0, 0, 1, 0}, {0, -1, 0, 0}, {0, 0, 0, -1}, 
       {1, 0, 0, 0}}, {{0, 0, -1, 0}, {0, 1, 0, 0}, {0, 0, 0, -1}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {-1, 0, 0, 0}, {0, 0, 1, 0}, 
       {0, 1, 0, 0}}, {{-1, 0, 0, 0}, {0, 0, 0, -1}, {0, 1, 0, 0}, 
       {0, 0, 1, 0}}, {{0, 0, 0, -1}, {0, 0, 1, 0}, {0, 1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, -1, 0, 0}, {0, 0, 0, 1}, {0, 0, -1, 0}, 
       {1, 0, 0, 0}}, {{0, -1, 0, 0}, {0, 0, 0, -1}, {0, 0, 1, 0}, 
       {1, 0, 0, 0}}, {{0, 1, 0, 0}, {0, 0, 0, -1}, {0, 0, -1, 0}, 
       {1, 0, 0, 0}}, {{-1, 0, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, -1}, 
       {0, 1, 0, 0}}, {{0, 0, 0, -1}, {0, 1, 0, 0}, {-1, 0, 0, 0}, 
       {0, 0, 1, 0}}, {{0, 0, 1, 0}, {0, 1, 0, 0}, {0, 0, 0, -1}, 
       {-1, 0, 0, 0}}, {{0, 1, 0, 0}, {0, 0, 0, -1}, {0, 0, 1, 0}, 
       {-1, 0, 0, 0}}}, {{{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, 1}}, {{0, -(-1)^(1/3), 0, 0}, {0, 0, -(-1)^(1/3), 0}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, 0, 0, -(-1)^(1/3)}}, 
      {{0, 0, 1, 0}, {0, 0, 0, 1}, {1, 0, 0, 0}, {0, 1, 0, 0}}, 
      {{0, 1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}}, 
      {{-1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 1}}, 
      {{-1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}, 
      {{-1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, -1}}, 
      {{0, 0, (-1)^(2/3), 0}, {(-1)^(2/3), 0, 0, 0}, {0, (-1)^(2/3), 0, 0}, 
       {0, 0, 0, (-1)^(2/3)}}, {{0, 0, 0, -(-1)^(1/3)}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}, 
       {0, -(-1)^(1/3), 0, 0}}, {{-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}}, {{0, -(-1)^(1/3), 0, 0}, 
       {0, 0, (-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}, {0, 0, 0, -(-1)^(1/3)}}, 
      {{0, (-1)^(1/3), 0, 0}, {0, 0, -(-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}}, {{0, (-1)^(1/3), 0, 0}, 
       {0, 0, (-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}, {0, 0, 0, (-1)^(1/3)}}, 
      {{0, 0, 0, 1}, {0, 0, 1, 0}, {0, 1, 0, 0}, {1, 0, 0, 0}}, 
      {{0, 0, -1, 0}, {0, 0, 0, 1}, {-1, 0, 0, 0}, {0, 1, 0, 0}}, 
      {{0, 0, 1, 0}, {0, 0, 0, 1}, {-1, 0, 0, 0}, {0, -1, 0, 0}}, 
      {{0, 0, -1, 0}, {0, 0, 0, -1}, {-1, 0, 0, 0}, {0, -1, 0, 0}}, 
      {{0, 1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, -1, 0}}, 
      {{0, -1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}}, 
      {{0, -1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, -1}, {0, 0, -1, 0}}, 
      {{1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 1}}, 
      {{1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, -1}}, 
      {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, -1}}, 
      {{(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, (-1)^(2/3), 0, 0}}, {{0, 0, 0, (-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}, 
       {(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}}, 
      {{0, 0, -(-1)^(2/3), 0}, {-(-1)^(2/3), 0, 0, 0}, {0, (-1)^(2/3), 0, 0}, 
       {0, 0, 0, (-1)^(2/3)}}, {{0, 0, (-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}, {0, -(-1)^(2/3), 0, 0}, 
       {0, 0, 0, (-1)^(2/3)}}, {{0, 0, -(-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}, {0, -(-1)^(2/3), 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}}, {{0, 0, -(-1)^(1/3), 0}, 
       {0, -(-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {-(-1)^(1/3), 0, 0, 0}}, {{0, 0, 0, -(-1)^(1/3)}, 
       {(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, {0, -(-1)^(1/3), 0, 0}}, 
      {{0, 0, 0, -(-1)^(1/3)}, {(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}, 
       {0, (-1)^(1/3), 0, 0}}, {{0, 0, 0, (-1)^(1/3)}, {(-1)^(1/3), 0, 0, 0}, 
       {0, 0, (-1)^(1/3), 0}, {0, (-1)^(1/3), 0, 0}}, 
      {{(-1)^(1/3), 0, 0, 0}, {0, 0, 0, -(-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}, 
       {0, 0, (-1)^(1/3), 0}}, {{(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}}, {{(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}, {0, 0, (-1)^(1/3), 0}}, 
      {{0, (-1)^(1/3), 0, 0}, {0, 0, (-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}}, {{0, (-1)^(1/3), 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}}, {{0, -(-1)^(1/3), 0, 0}, 
       {0, 0, (-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}, {0, 0, 0, (-1)^(1/3)}}, 
      {{0, 0, 0, 1}, {0, 0, -1, 0}, {0, 1, 0, 0}, {-1, 0, 0, 0}}, 
      {{0, 0, 0, 1}, {0, 0, 1, 0}, {0, -1, 0, 0}, {-1, 0, 0, 0}}, 
      {{0, 0, 0, -1}, {0, 0, -1, 0}, {0, -1, 0, 0}, {-1, 0, 0, 0}}, 
      {{0, 0, -1, 0}, {0, 0, 0, 1}, {1, 0, 0, 0}, {0, -1, 0, 0}}, 
      {{0, 0, 1, 0}, {0, 0, 0, -1}, {1, 0, 0, 0}, {0, -1, 0, 0}}, 
      {{0, 0, -1, 0}, {0, 0, 0, -1}, {1, 0, 0, 0}, {0, 1, 0, 0}}, 
      {{0, -1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, -1, 0}}, 
      {{0, -1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, -1}, {0, 0, 1, 0}}, 
      {{0, 1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, -1}, {0, 0, -1, 0}}, 
      {{-1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, -1}}, 
      {{0, (-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, {0, 0, (-1)^(2/3), 0}, 
       {(-1)^(2/3), 0, 0, 0}}, {{-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}, {0, 0, 0, (-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}}, 
      {{-(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}}, {{-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}, {0, 0, 0, -(-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}}, {{0, 0, 0, (-1)^(2/3)}, 
       {0, (-1)^(2/3), 0, 0}, {-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}}, {{0, 0, 0, (-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}, {-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, (-1)^(2/3), 0}}, {{0, 0, 0, -(-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}, {-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}}, {{0, 0, -(-1)^(2/3), 0}, 
       {(-1)^(2/3), 0, 0, 0}, {0, -(-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}}, 
      {{0, 0, (-1)^(2/3), 0}, {(-1)^(2/3), 0, 0, 0}, {0, -(-1)^(2/3), 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}}, {{0, 0, -(-1)^(2/3), 0}, 
       {(-1)^(2/3), 0, 0, 0}, {0, (-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}}, 
      {{0, 0, (-1)^(1/3), 0}, {0, -(-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {(-1)^(1/3), 0, 0, 0}}, {{0, 0, -(-1)^(1/3), 0}, 
       {0, (-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, {(-1)^(1/3), 0, 0, 0}}, 
      {{0, 0, (-1)^(1/3), 0}, {0, (-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}, 
       {(-1)^(1/3), 0, 0, 0}}, {{0, 0, 0, -(-1)^(1/3)}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, {0, (-1)^(1/3), 0, 0}}, 
      {{0, 0, 0, (-1)^(1/3)}, {-(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}, 
       {0, (-1)^(1/3), 0, 0}}, {{0, 0, 0, (-1)^(1/3)}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, 
       {0, -(-1)^(1/3), 0, 0}}, {{-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}, {0, 0, (-1)^(1/3), 0}}, 
      {{-(-1)^(1/3), 0, 0, 0}, {0, 0, 0, (-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}}, {{-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}, {0, 0, (-1)^(1/3), 0}}, 
      {{0, -(-1)^(1/3), 0, 0}, {0, 0, -(-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}}, {{0, 0, 0, 1}, {0, 0, -1, 0}, {0, -1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, 1, 0}, {0, -1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, -1, 0}, {0, 1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 1, 0}, {0, 0, 0, -1}, {-1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, 1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, 1, 0}}, {{0, (-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, 0, -(-1)^(2/3), 0}, {-(-1)^(2/3), 0, 0, 0}}, 
      {{0, -(-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, {0, 0, (-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}}, {{0, -(-1)^(2/3), 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}, {0, 0, -(-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}}, {{(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}}, {{(-1)^(2/3), 0, 0, 0}, 
       {0, 0, (-1)^(2/3), 0}, {0, 0, 0, -(-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}}, {{(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}, {0, 0, 0, -(-1)^(2/3)}, 
       {0, (-1)^(2/3), 0, 0}}, {{0, 0, 0, (-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}, {(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}}, {{0, 0, 0, -(-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}, {(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}}, 
      {{0, 0, 0, -(-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}, {(-1)^(2/3), 0, 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}}, {{0, 0, (-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}, {0, (-1)^(2/3), 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}}, {{0, 0, (-1)^(1/3), 0}, 
       {0, (-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {-(-1)^(1/3), 0, 0, 0}}, {{0, 0, -(-1)^(1/3), 0}, 
       {0, (-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}, {-(-1)^(1/3), 0, 0, 0}}, 
      {{0, 0, (-1)^(1/3), 0}, {0, -(-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}, 
       {-(-1)^(1/3), 0, 0, 0}}, {{0, 0, 0, (-1)^(1/3)}, 
       {(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}, 
       {0, -(-1)^(1/3), 0, 0}}, {{(-1)^(1/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}}, {{0, 0, 0, -1}, {0, 0, 1, 0}, {0, 1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, -(-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, 0, -(-1)^(2/3), 0}, {(-1)^(2/3), 0, 0, 0}}, 
      {{0, -(-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}, {0, 0, (-1)^(2/3), 0}, 
       {(-1)^(2/3), 0, 0, 0}}, {{0, (-1)^(2/3), 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}, {0, 0, -(-1)^(2/3), 0}, 
       {(-1)^(2/3), 0, 0, 0}}, {{-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, (-1)^(2/3), 0}, {0, 0, 0, -(-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}}, 
      {{0, 0, 0, -(-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}, {-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, (-1)^(2/3), 0}}, {{0, 0, -(-1)^(1/3), 0}, 
       {0, -(-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}, {(-1)^(1/3), 0, 0, 0}}, 
      {{0, (-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}, {0, 0, (-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}}}, {{{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, 1}}, {{0, (-1)^(2/3), 0, 0}, {0, 0, (-1)^(2/3), 0}, 
       {(-1)^(2/3), 0, 0, 0}, {0, 0, 0, (-1)^(2/3)}}, 
      {{0, 0, 1, 0}, {0, 0, 0, 1}, {1, 0, 0, 0}, {0, 1, 0, 0}}, 
      {{0, 1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}}, 
      {{-1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 1}}, 
      {{-1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}, 
      {{-1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, -1}}, 
      {{0, 0, -(-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}, 
       {0, -(-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}}, 
      {{0, 0, 0, (-1)^(2/3)}, {(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}}, {{(-1)^(2/3), 0, 0, 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, (-1)^(2/3), 0, 0}, {0, 0, (-1)^(2/3), 0}}, 
      {{0, (-1)^(2/3), 0, 0}, {0, 0, -(-1)^(2/3), 0}, {-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(2/3)}}, {{0, -(-1)^(2/3), 0, 0}, 
       {0, 0, (-1)^(2/3), 0}, {-(-1)^(2/3), 0, 0, 0}, {0, 0, 0, (-1)^(2/3)}}, 
      {{0, -(-1)^(2/3), 0, 0}, {0, 0, -(-1)^(2/3), 0}, 
       {-(-1)^(2/3), 0, 0, 0}, {0, 0, 0, -(-1)^(2/3)}}, 
      {{0, 0, 0, 1}, {0, 0, 1, 0}, {0, 1, 0, 0}, {1, 0, 0, 0}}, 
      {{0, 0, -1, 0}, {0, 0, 0, 1}, {-1, 0, 0, 0}, {0, 1, 0, 0}}, 
      {{0, 0, 1, 0}, {0, 0, 0, 1}, {-1, 0, 0, 0}, {0, -1, 0, 0}}, 
      {{0, 0, -1, 0}, {0, 0, 0, -1}, {-1, 0, 0, 0}, {0, -1, 0, 0}}, 
      {{0, 1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, -1, 0}}, 
      {{0, -1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}}, 
      {{0, -1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, -1}, {0, 0, -1, 0}}, 
      {{1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 1}}, 
      {{1, 0, 0, 0}, {0, -1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, -1}}, 
      {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, -1}}, 
      {{-(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}, 
       {0, 0, 0, -(-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}}, 
      {{0, 0, 0, -(-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}}, 
      {{0, 0, (-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}, {0, -(-1)^(1/3), 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}}, {{0, 0, -(-1)^(1/3), 0}, 
       {(-1)^(1/3), 0, 0, 0}, {0, (-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}}, 
      {{0, 0, (-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}, {0, (-1)^(1/3), 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}}, {{0, 0, (-1)^(2/3), 0}, {0, (-1)^(2/3), 0, 0}, 
       {0, 0, 0, (-1)^(2/3)}, {(-1)^(2/3), 0, 0, 0}}, 
      {{0, 0, 0, (-1)^(2/3)}, {-(-1)^(2/3), 0, 0, 0}, {0, 0, -(-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}}, {{0, 0, 0, (-1)^(2/3)}, 
       {-(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}, 
       {0, -(-1)^(2/3), 0, 0}}, {{0, 0, 0, -(-1)^(2/3)}, 
       {-(-1)^(2/3), 0, 0, 0}, {0, 0, -(-1)^(2/3), 0}, 
       {0, -(-1)^(2/3), 0, 0}}, {{-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, (-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}, {0, 0, -(-1)^(2/3), 0}}, 
      {{-(-1)^(2/3), 0, 0, 0}, {0, 0, 0, (-1)^(2/3)}, {0, -(-1)^(2/3), 0, 0}, 
       {0, 0, (-1)^(2/3), 0}}, {{-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}, {0, -(-1)^(2/3), 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}}, {{0, -(-1)^(2/3), 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}, {(-1)^(2/3), 0, 0, 0}, {0, 0, 0, (-1)^(2/3)}}, 
      {{0, -(-1)^(2/3), 0, 0}, {0, 0, (-1)^(2/3), 0}, {(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}}, {{0, (-1)^(2/3), 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}, {(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}}, {{0, 0, 0, 1}, {0, 0, -1, 0}, {0, 1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, 0, 0, 1}, {0, 0, 1, 0}, {0, -1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, -1, 0}, {0, -1, 0, 0}, 
       {-1, 0, 0, 0}}, {{0, 0, -1, 0}, {0, 0, 0, 1}, {1, 0, 0, 0}, 
       {0, -1, 0, 0}}, {{0, 0, 1, 0}, {0, 0, 0, -1}, {1, 0, 0, 0}, 
       {0, -1, 0, 0}}, {{0, 0, -1, 0}, {0, 0, 0, -1}, {1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, -1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 1}, 
       {0, 0, -1, 0}}, {{0, -1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, 1, 0}}, {{0, 1, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, -1, 0}}, {{-1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, 
       {0, 0, 0, -1}}, {{0, -(-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {0, 0, -(-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}}, 
      {{(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {0, -(-1)^(1/3), 0, 0}}, {{(-1)^(1/3), 0, 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {0, (-1)^(1/3), 0, 0}}, {{(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}}, 
      {{0, 0, 0, -(-1)^(1/3)}, {0, -(-1)^(1/3), 0, 0}, {(-1)^(1/3), 0, 0, 0}, 
       {0, 0, (-1)^(1/3), 0}}, {{0, 0, 0, -(-1)^(1/3)}, 
       {0, (-1)^(1/3), 0, 0}, {(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}}, 
      {{0, 0, 0, (-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}, {(-1)^(1/3), 0, 0, 0}, 
       {0, 0, (-1)^(1/3), 0}}, {{0, 0, (-1)^(1/3), 0}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, (-1)^(1/3), 0, 0}, 
       {0, 0, 0, -(-1)^(1/3)}}, {{0, 0, -(-1)^(1/3), 0}, 
       {-(-1)^(1/3), 0, 0, 0}, {0, (-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}}, 
      {{0, 0, (-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}, {0, -(-1)^(1/3), 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}}, {{0, 0, -(-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, {-(-1)^(2/3), 0, 0, 0}}, 
      {{0, 0, (-1)^(2/3), 0}, {0, -(-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, 
       {-(-1)^(2/3), 0, 0, 0}}, {{0, 0, -(-1)^(2/3), 0}, 
       {0, -(-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}, 
       {-(-1)^(2/3), 0, 0, 0}}, {{0, 0, 0, (-1)^(2/3)}, 
       {(-1)^(2/3), 0, 0, 0}, {0, 0, -(-1)^(2/3), 0}, 
       {0, -(-1)^(2/3), 0, 0}}, {{0, 0, 0, -(-1)^(2/3)}, 
       {(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}, {0, -(-1)^(2/3), 0, 0}}, 
      {{0, 0, 0, -(-1)^(2/3)}, {(-1)^(2/3), 0, 0, 0}, {0, 0, -(-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}}, {{(-1)^(2/3), 0, 0, 0}, {0, 0, 0, (-1)^(2/3)}, 
       {0, -(-1)^(2/3), 0, 0}, {0, 0, -(-1)^(2/3), 0}}, 
      {{(-1)^(2/3), 0, 0, 0}, {0, 0, 0, -(-1)^(2/3)}, {0, -(-1)^(2/3), 0, 0}, 
       {0, 0, (-1)^(2/3), 0}}, {{(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}, 
       {0, 0, -(-1)^(2/3), 0}}, {{0, (-1)^(2/3), 0, 0}, 
       {0, 0, (-1)^(2/3), 0}, {-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}}, {{0, 0, 0, 1}, {0, 0, -1, 0}, {0, -1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, 1, 0}, {0, -1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 0, -1}, {0, 0, -1, 0}, {0, 1, 0, 0}, 
       {1, 0, 0, 0}}, {{0, 0, 1, 0}, {0, 0, 0, -1}, {-1, 0, 0, 0}, 
       {0, 1, 0, 0}}, {{0, 1, 0, 0}, {-1, 0, 0, 0}, {0, 0, 0, -1}, 
       {0, 0, 1, 0}}, {{0, -(-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {0, 0, (-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}}, 
      {{0, (-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, {0, 0, -(-1)^(1/3), 0}, 
       {(-1)^(1/3), 0, 0, 0}}, {{0, (-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}, 
       {0, 0, (-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}}, 
      {{-(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, {0, 0, 0, -(-1)^(1/3)}, 
       {0, (-1)^(1/3), 0, 0}}, {{-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}, {0, 0, 0, (-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}}, 
      {{-(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}, {0, 0, 0, (-1)^(1/3)}, 
       {0, -(-1)^(1/3), 0, 0}}, {{0, 0, 0, -(-1)^(1/3)}, 
       {0, (-1)^(1/3), 0, 0}, {-(-1)^(1/3), 0, 0, 0}, {0, 0, (-1)^(1/3), 0}}, 
      {{0, 0, 0, (-1)^(1/3)}, {0, (-1)^(1/3), 0, 0}, {-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}}, {{0, 0, 0, (-1)^(1/3)}, 
       {0, -(-1)^(1/3), 0, 0}, {-(-1)^(1/3), 0, 0, 0}, 
       {0, 0, (-1)^(1/3), 0}}, {{0, 0, -(-1)^(1/3), 0}, 
       {(-1)^(1/3), 0, 0, 0}, {0, -(-1)^(1/3), 0, 0}, {0, 0, 0, (-1)^(1/3)}}, 
      {{0, 0, -(-1)^(2/3), 0}, {0, -(-1)^(2/3), 0, 0}, {0, 0, 0, (-1)^(2/3)}, 
       {(-1)^(2/3), 0, 0, 0}}, {{0, 0, (-1)^(2/3), 0}, 
       {0, -(-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}, 
       {(-1)^(2/3), 0, 0, 0}}, {{0, 0, -(-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}, {(-1)^(2/3), 0, 0, 0}}, 
      {{0, 0, 0, -(-1)^(2/3)}, {-(-1)^(2/3), 0, 0, 0}, {0, 0, (-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}}, {{-(-1)^(2/3), 0, 0, 0}, 
       {0, 0, 0, -(-1)^(2/3)}, {0, (-1)^(2/3), 0, 0}, {0, 0, (-1)^(2/3), 0}}, 
      {{0, 0, 0, -1}, {0, 0, 1, 0}, {0, 1, 0, 0}, {-1, 0, 0, 0}}, 
      {{0, (-1)^(1/3), 0, 0}, {0, 0, 0, -(-1)^(1/3)}, {0, 0, (-1)^(1/3), 0}, 
       {-(-1)^(1/3), 0, 0, 0}}, {{0, (-1)^(1/3), 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, 0, -(-1)^(1/3), 0}, 
       {-(-1)^(1/3), 0, 0, 0}}, {{0, -(-1)^(1/3), 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, 0, (-1)^(1/3), 0}, {-(-1)^(1/3), 0, 0, 0}}, 
      {{(-1)^(1/3), 0, 0, 0}, {0, 0, -(-1)^(1/3), 0}, {0, 0, 0, (-1)^(1/3)}, 
       {0, -(-1)^(1/3), 0, 0}}, {{0, 0, 0, (-1)^(1/3)}, 
       {0, -(-1)^(1/3), 0, 0}, {(-1)^(1/3), 0, 0, 0}, 
       {0, 0, -(-1)^(1/3), 0}}, {{0, 0, (-1)^(2/3), 0}, 
       {0, (-1)^(2/3), 0, 0}, {0, 0, 0, -(-1)^(2/3)}, 
       {-(-1)^(2/3), 0, 0, 0}}, {{0, -(-1)^(1/3), 0, 0}, 
       {0, 0, 0, (-1)^(1/3)}, {0, 0, -(-1)^(1/3), 0}, {(-1)^(1/3), 0, 0, 0}}}}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["Size"] = 96
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["SizeConjugacyClasses"] = 
    {1, 16, 6, 6, 1, 16, 16, 6, 6, 6, 16}
 
ModelBuilding`DiscreteSymmetries`Private`Group$705["StructureDescription"] = 
    "((C2 x D8) : C2) : C3"
 
ModelBuilding`DiscreteSymmetries`Private`Group$705[
     "UnitaryRepresentations"] = True
